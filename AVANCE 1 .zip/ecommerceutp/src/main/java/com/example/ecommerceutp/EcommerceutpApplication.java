package com.example.ecommerceutp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"com.example.ecommerceutp"})

public class EcommerceutpApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcommerceutpApplication.class, args);
	}

}
