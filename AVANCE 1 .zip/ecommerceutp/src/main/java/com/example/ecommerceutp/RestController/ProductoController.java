package com.example.ecommerceutp.RestController;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.bind.annotation.*;

import ecommenceutp.clases.Producto;

@RestController
@RequestMapping("/productos")
public class ProductoController {

    public static Map<Long, Producto> productos = new HashMap<>();
    private static long nextId = 1;

    /* Registrar un nuevo producto */
    @PostMapping
    public Producto registrar(@RequestBody Producto nuevo) {
        if (nuevo.getPrecio() <= 0 || nuevo.getStock() < 0) {
            throw new ResponseStatusException(
                HttpStatus.BAD_REQUEST, "Precio debe ser mayor a 0 y stock no negativo"
            );
        }
        nuevo.setId(nextId++);
        productos.put(nuevo.getId(), nuevo);
        return nuevo;
    }

    /* Listar todos los productos */
    @GetMapping
    public Collection<Producto> listar() { //funcional
        return productos.values();
    }

    /* Buscar producto por ID */
    @GetMapping("/{id}")
    public Producto obtenerPorId(@PathVariable("id") Long id) { //funcional
        Producto producto = productos.get(id);
        if (producto == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Producto no encontrado");
        }
        return producto;
    }

    /* Actualizar un producto existente */
    @PutMapping("/{id}")
    public Producto actualizar(@PathVariable("id") Long id, @RequestBody Producto actualizado) { //funcional
        Producto existente = productos.get(id);
        if (existente == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Producto no encontrado");
        }
        if (actualizado.getPrecio() <= 0 || actualizado.getStock() < 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Precio debe ser mayor a 0 y stock no negativo");
        }
        actualizado.setId(id);
        productos.put(id, actualizado);
        return actualizado;
    }

    /* Eliminar un producto */
    @DeleteMapping("/{id}")
    public String eliminar(@PathVariable("id") Long id) { //funcional
        Producto eliminado = productos.remove(id);
        if (eliminado == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Producto no encontrado");
        }
        return "Producto eliminado correctamente";
    }

    /* Método estático para usar en CarritoController */
    public static Producto getProducto(Long id) {
        return productos.get(id);
    }
}
