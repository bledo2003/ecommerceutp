package com.example.ecommerceutp.RestController;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import ecommenceutp.clases.Carrito;
import ecommenceutp.clases.Pedido;
import ecommenceutp.clases.Producto;

@RestController
@RequestMapping("/carrito")
public class CarritoController {

	public static Map<Long, Carrito> carritos = new HashMap<>();
    public static long nextId = 1;
    /* Agrega un producto al carrito de un cliente */
    @PostMapping("/{clienteId}/agregar/{productoId}")
    public Carrito agregar(@PathVariable("clienteId") Long clienteId, @PathVariable("productoId") Long productoId) {
        Carrito carrito = carritos.get(clienteId);
        if (carrito == null) {
            carrito = new Carrito((int) nextId++, clienteId, 0.0, true);
            carritos.put(clienteId, carrito);
        }

        Producto producto = ProductoController.getProducto(productoId);
        if (producto == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Producto no encontrado");
        }

        carrito.agregarProducto(producto); // ahora también se guarda en la lista
        return carrito;
    }

    /* Elimina un producto del carrito de un cliente */
    @DeleteMapping("/{clienteId}/eliminar/{productoId}")
    public Carrito eliminar(@PathVariable("clienteId") Long clienteId, @PathVariable("productoId") Long productoId) {
        Carrito carrito = carritos.get(clienteId);
        if (carrito == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Carrito no encontrado");
        }

        Producto producto = ProductoController.getProducto(productoId);
        if (producto == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Producto no encontrado");
        }

        carrito.eliminarProducto(producto); // también actualiza lista
        return carrito;
    }

    /* Finaliza la compra del carrito y genera un pedido */
    @PostMapping("/{clienteId}/checkout")
    public Pedido checkout(@PathVariable("clienteId") Long clienteId) {
        Carrito carrito = carritos.get(clienteId);
        if (carrito == null || carrito.getTotal() <= 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Carrito vacío");
        }

        // Generar pedido
        Pedido pedido = new Pedido(
        	    (int) nextId++,
        	    clienteId,
        	    LocalDate.now(),
        	    Double.valueOf(carrito.getTotal()), // conversión explícita
        	    "CONFIRMADO"
        	);

        carrito.setActivo(false);
        return pedido;
    }

    /* Obtiene el carrito de un cliente */
    @GetMapping("/{clienteId}")
    public Carrito verCarrito(@PathVariable("clienteId") Long clienteId) {
        Carrito carrito = carritos.get(clienteId);
        if (carrito == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Carrito vacío");
        }
        return carrito;
    }
}
