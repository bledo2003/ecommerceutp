package ecommenceutp.clases;

import java.time.LocalDate;

public class Pedido {
    
    private int id;
    private Long clienteId;
    private LocalDate fecha;
    private Double total;
    private String estado;
    
    // ✅ Constructor vacío (lo usa Spring en algunos casos)
    public Pedido() {
    }
    
    // ✅ Constructor completo (el que necesitas en CarritoController)
    public Pedido(int id, Long clienteId, LocalDate fecha, Double total, String estado) {
        this.id = id;
        this.clienteId = clienteId;
        this.fecha = fecha;
        this.total = total;
        this.estado = estado;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public Long getClienteId() {
        return clienteId;
    }
    public void setClienteId(Long clienteId) {
        this.clienteId = clienteId;
    }

    public LocalDate getFecha() {
        return fecha;
    }
    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public Double getTotal() {
        return total;
    }
    public void setTotal(Double total) {
        this.total = total;
    }

    public String getEstado() {
        return estado;
    }
    public void setEstado(String estado) {
        this.estado = estado;
    }
}
