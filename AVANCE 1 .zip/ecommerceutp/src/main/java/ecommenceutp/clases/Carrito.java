package ecommenceutp.clases;

import java.util.ArrayList;
import java.util.List;

public class Carrito {
    
    private int id;
    private Long clienteId;
    private Double total;
    private boolean activo;
    private List<Producto> productos;  // lista de productos en el carrito
    
    // ✅ Constructor
    public Carrito(int id, Long clienteId, Double total, boolean activo) {
        this.id = id;
        this.clienteId = clienteId;
        this.total = total;
        this.activo = activo;
        this.productos = new ArrayList<>();
    }

    // ✅ Método para agregar producto
    public void agregarProducto(Producto producto) {
        productos.add(producto);
        total += producto.getPrecio();
    }

    // ✅ Método para eliminar producto
    public void eliminarProducto(Producto producto) {
        if (productos.remove(producto)) { // solo resta si realmente estaba en el carrito
            total -= producto.getPrecio();
        }
    }

    // Getters y Setters
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public Long getClienteId() {
        return clienteId;
    }
    public void setClienteId(Long clienteId) {
        this.clienteId = clienteId;
    }

    public Double getTotal() {
        return total;
    }
    public void setTotal(Double total) {
        this.total = total;
    }

    public boolean isActivo() {
        return activo;
    }
    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public List<Producto> getProductos() {
        return productos;
    }
    public void setProductos(List<Producto> productos) {
        this.productos = productos;
    }
}
