package ecommenceutp.clases;


public class Usuario {

    private Long id;
    private String username;
    private String password;
    private String rol;   
    private Boolean activo;
    
    
    public Usuario() {
	}
    
	public Usuario(Long id, String username, String password, String rol, Boolean activo) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.rol = rol;
		this.activo = activo;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRol() {
		return rol;
	}
	public void setRol(String rol) {
		this.rol = rol;
	}
	public Boolean getActivo() {
		return activo;
	}
	public void setActivo(Boolean activo) {
		this.activo = activo;
	}

    
    
}