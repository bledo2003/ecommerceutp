package com.example.ecommerceutp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceutpApplicationTests {

	@Test
	void contextLoads() {
	}

}
