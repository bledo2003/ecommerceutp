package com.example.ecommerceutp.RestController;

import ecommenceutp.clases.Producto;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class ProductoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setup() throws Exception {
        ProductoController.productos.clear();   // Limpia el mapa
        java.lang.reflect.Field field = ProductoController.class.getDeclaredField("nextId");
        field.setAccessible(true);
        field.set(null, 1L); // Reinicia el contador estático

        Producto p1 = new Producto(null, "Laptop", "Laptop básica", 3000.0, 5);
        Producto p2 = new Producto(null, "Mouse", "Mouse inalámbrico", 50.0, 20);

        mockMvc.perform(post("/productos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(p1)))
                .andExpect(status().isOk());

        mockMvc.perform(post("/productos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(p2)))
                .andExpect(status().isOk());
    }

    // -------------------------------
    // PRUEBAS DE ACTUALIZAR PRODUCTO
    // -------------------------------

    @Test
    void actualizarProducto_exitoso() throws Exception {
        Producto actualizado = new Producto(1L, "Laptop Gamer", "Laptop para juegos", 4500.0, 10);

        mockMvc.perform(put("/productos/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(actualizado)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombre").value("Laptop Gamer"))
                .andExpect(jsonPath("$.precio").value(4500.0))
                .andExpect(jsonPath("$.stock").value(10));
    }

    @Test
    void actualizarProducto_noEncontrado() throws Exception {
        Producto actualizado = new Producto(99L, "Tablet", "Tablet económica", 1200.0, 3);

        mockMvc.perform(put("/productos/99")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(actualizado)))
                .andExpect(status().is4xxClientError()); // ahora espera 404
    }

    @Test
    void actualizarProducto_datosInvalidos() throws Exception {
        Producto actualizado = new Producto(1L, "Celular", "Celular barato", -500.0, 5);

        mockMvc.perform(put("/productos/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(actualizado)))
                .andExpect(status().is4xxClientError()); // ahora espera 400
    }

    // -------------------------------
    // PRUEBAS DE ELIMINAR PRODUCTO
    // -------------------------------

    @Test
    void eliminarProducto_exitoso() throws Exception {
        mockMvc.perform(delete("/productos/2"))
                .andExpect(status().isOk())
                .andExpect(content().string("Producto eliminado correctamente"));
    }

    @Test
    void eliminarProducto_noEncontrado() throws Exception {
        mockMvc.perform(delete("/productos/100"))
                .andExpect(status().is4xxClientError()); // ahora espera 404
    }

    @Test
    void eliminarProducto_dosVeces() throws Exception {
        // Primera vez elimina
        mockMvc.perform(delete("/productos/2"))
                .andExpect(status().isOk());

        // Segunda vez ya no existe
        mockMvc.perform(delete("/productos/2"))
                .andExpect(status().is4xxClientError()); // ahora espera 404
    }
    

    // -------------------------------
    // PRUEBAS DE REGISTRAR PRODUCTO (POST)
    // -------------------------------

    @Test
    void registrarProducto_exitoso() throws Exception {
        Producto nuevo = new Producto(null, "Teclado", "Teclado mecánico", 150.0, 15);

        mockMvc.perform(post("/productos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(nuevo)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").exists())
                .andExpect(jsonPath("$.nombre").value("Teclado"))
                .andExpect(jsonPath("$.precio").value(150.0))
                .andExpect(jsonPath("$.stock").value(15));
    }

    @Test
    void registrarProducto_datosInvalidos() throws Exception {
        Producto invalido = new Producto(null, "Monitor", "Monitor defectuoso", -200.0, -5);

        mockMvc.perform(post("/productos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(invalido)))
                .andExpect(status().isBadRequest()); // BAD_REQUEST esperado
    }

    @Test
    void registrarProducto_stockCeroPermitido() throws Exception {
        Producto nuevo = new Producto(null, "Cable HDMI", "Cable 2m", 20.0, 0);

        mockMvc.perform(post("/productos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(nuevo)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombre").value("Cable HDMI"))
                .andExpect(jsonPath("$.stock").value(0));
    }

    // -------------------------------
    // PRUEBAS DE LISTAR PRODUCTOS (GET)
    // -------------------------------

    @Test
    void listarProductos_exitoso() throws Exception {
        mockMvc.perform(get("/productos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$.length()").value(2));
    }

    @Test
    void listarProductos_vacio() throws Exception {
        ProductoController.productos.clear();

        mockMvc.perform(get("/productos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$.length()").value(0));
    }

    @Test
    void listarProductos_conNuevoProducto() throws Exception {
        Producto nuevo = new Producto(null, "Impresora", "Impresora multifuncional", 600.0, 3);

        mockMvc.perform(post("/productos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(nuevo)))
                .andExpect(status().isOk());

        mockMvc.perform(get("/productos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$.length()").value(3))
                .andExpect(jsonPath("$[2].nombre").value("Impresora"));
    }
    
}
