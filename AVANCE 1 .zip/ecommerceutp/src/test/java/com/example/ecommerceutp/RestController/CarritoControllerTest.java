package com.example.ecommerceutp.RestController;

import ecommenceutp.clases.Producto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class CarritoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setup() {
        CarritoController.carritos.clear();
        CarritoController.nextId = 1;
        ProductoController.productos.clear();
        try {
            java.lang.reflect.Field field = ProductoController.class.getDeclaredField("nextId");
            field.setAccessible(true);
            field.set(null, 1L);
        } catch (Exception ignored) {}
    }

    // -------------------------------
    // PRUEBAS DE AGREGAR PRODUCTO
    // -------------------------------

    @Test
    void agregarProducto_exitoso() throws Exception {
        Producto nuevo = new Producto(null, "Laptop", "Laptop gamer", 3500.0, 5);
        mockMvc.perform(post("/productos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(nuevo)))
                .andExpect(status().isOk());

        mockMvc.perform(post("/carrito/1/agregar/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.clienteId").value(1))
                .andExpect(jsonPath("$.productos[0].nombre").value("Laptop"));
    }

    @Test
    void agregarProducto_productoNoEncontrado() throws Exception {
        mockMvc.perform(post("/carrito/1/agregar/99"))
                .andExpect(status().isNotFound())
                .andExpect(status().reason("Producto no encontrado"));
    }

    @Test
    void agregarProducto_variosProductos() throws Exception {
        Producto p1 = new Producto(null, "Mouse", "Mouse gamer", 100.0, 10);
        Producto p2 = new Producto(null, "Teclado", "Teclado mecánico", 200.0, 8);

        mockMvc.perform(post("/productos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(p1)))
                .andExpect(status().isOk());

        mockMvc.perform(post("/productos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(p2)))
                .andExpect(status().isOk());

        mockMvc.perform(post("/carrito/1/agregar/1"))
                .andExpect(status().isOk());

        mockMvc.perform(post("/carrito/1/agregar/2"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.productos.length()").value(2));
    }

    // -------------------------------
    // PRUEBAS DE ELIMINAR PRODUCTO
    // -------------------------------

    @Test
    void eliminarProducto_exitoso() throws Exception {
        Producto nuevo = new Producto(null, "Monitor", "Monitor 27 pulgadas", 1200.0, 4);
        mockMvc.perform(post("/productos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(nuevo)))
                .andExpect(status().isOk());

        mockMvc.perform(post("/carrito/2/agregar/1"))
                .andExpect(status().isOk());

        mockMvc.perform(delete("/carrito/2/eliminar/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.productos.length()").value(0));
    }

    @Test
    void eliminarProducto_carritoNoEncontrado() throws Exception {
        mockMvc.perform(delete("/carrito/99/eliminar/1"))
                .andExpect(status().isNotFound())
                .andExpect(status().reason("Carrito no encontrado"));
    }

    @Test
    void eliminarProducto_productoNoEncontrado() throws Exception {
        Producto nuevo = new Producto(null, "Tablet", "Tablet Android", 800.0, 3);
        mockMvc.perform(post("/productos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(nuevo)))
                .andExpect(status().isOk());

        mockMvc.perform(post("/carrito/3/agregar/1"))
                .andExpect(status().isOk());

        mockMvc.perform(delete("/carrito/3/eliminar/99"))
                .andExpect(status().isNotFound())
                .andExpect(status().reason("Producto no encontrado"));
    }

    // -------------------------------
    // PRUEBAS DE CHECKOUT
    // -------------------------------

    @Test
    void checkout_exitoso() throws Exception {
        Producto nuevo = new Producto(null, "Silla", "Silla ergonómica", 900.0, 2);
        mockMvc.perform(post("/productos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(nuevo)))
                .andExpect(status().isOk());

        mockMvc.perform(post("/carrito/4/agregar/1"))
                .andExpect(status().isOk());

        mockMvc.perform(post("/carrito/4/checkout"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("CONFIRMADO"))
                .andExpect(jsonPath("$.total").value(900.0));
    }

    @Test
    void checkout_carritoVacio() throws Exception {
        mockMvc.perform(post("/carrito/5/checkout"))
                .andExpect(status().isBadRequest())
                .andExpect(status().reason("Carrito vacío"));
    }

    @Test
    void checkout_carritoConVariosProductos() throws Exception {
        Producto p1 = new Producto(null, "Auriculares", "Auriculares Bluetooth", 300.0, 6);
        Producto p2 = new Producto(null, "Microfono", "Micrófono USB", 250.0, 4);

        mockMvc.perform(post("/productos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(p1)))
                .andExpect(status().isOk());

        mockMvc.perform(post("/productos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(p2)))
                .andExpect(status().isOk());

        mockMvc.perform(post("/carrito/6/agregar/1"))
                .andExpect(status().isOk());

        mockMvc.perform(post("/carrito/6/agregar/2"))
                .andExpect(status().isOk());

        mockMvc.perform(post("/carrito/6/checkout"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.total").value(550.0));
    }

    // -------------------------------
    // PRUEBAS DE VER CARRITO
    // -------------------------------

    @Test
    void verCarrito_exitoso() throws Exception {
        Producto nuevo = new Producto(null, "Parlante", "Parlante Bluetooth", 400.0, 5);
        mockMvc.perform(post("/productos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(nuevo)))
                .andExpect(status().isOk());

        mockMvc.perform(post("/carrito/7/agregar/1"))
                .andExpect(status().isOk());

        mockMvc.perform(get("/carrito/7"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.productos[0].nombre").value("Parlante"));
    }

    @Test
    void verCarrito_carritoVacio() throws Exception {
        mockMvc.perform(get("/carrito/99"))
                .andExpect(status().isNotFound())
                .andExpect(status().reason("Carrito vacío"));
    }

    @Test
    void verCarrito_conVariosProductos() throws Exception {
        Producto p1 = new Producto(null, "Camara", "Cámara digital", 1500.0, 2);
        Producto p2 = new Producto(null, "Tripode", "Trípode profesional", 500.0, 3);

        mockMvc.perform(post("/productos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(p1)))
                .andExpect(status().isOk());

        mockMvc.perform(post("/productos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(p2)))
                .andExpect(status().isOk());

        mockMvc.perform(post("/carrito/8/agregar/1"))
                .andExpect(status().isOk());

        mockMvc.perform(post("/carrito/8/agregar/2"))
                .andExpect(status().isOk());

        mockMvc.perform(get("/carrito/8"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.productos.length()").value(2));
    }
}
    